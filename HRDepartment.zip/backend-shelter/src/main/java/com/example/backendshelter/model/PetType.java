package com.example.backendshelter.model;

public enum PetType {
    CAT,
    DOG,
    EAGLE,
}
