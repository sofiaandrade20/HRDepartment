package com.example.backendshelter.service;

import com.example.backendshelter.repository.FoodRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FoodService {

    @Autowired
    private FoodRepository foodRepository;


    public void save(Long aLong){
    }
}
