package com.example.backendshelter.request;

import com.example.backendshelter.model.PetType;
import lombok.*;

import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreatePetRQ {
    @Enumerated
    private PetType petType;
    @NotBlank(message = "Name is a mandatory field.")
    private String name;
}
